clc; clear all;

% Load the fixed reference image, here is DAPI image for frame 1 and 2
fixed = dir('251*.tif');
fixedImage = imread(fixed.name);

% Load the moving image to align, here is DAPI image for frame 3 and 4
moving = dir('252*.tif');
movingImage = imread(moving.name);

% Estimate the geometric transformation
tform = imregcorr(movingImage, fixedImage); 

% read segmented cells
cell_masks = imread('O-open_crop4_correction.png');

%
% 1. Make a single label image from all binary cell masks
labeled_cells = bwlabel(cell_masks); 

% 2. Get the coordinates of each mRNA dot
% load('TrackGUIoutput.mat')
% load('ORG1.mat')
%%
load('ORG2-4.mat')

%%
% define frame 
% ====================================================================
match_col = find(objs(5, :) == 3); % 1 means frame 1 <<<==============
% dot_coords = objs([1,2], match_col)';

% Transform the points forward (from moving image space to fixed image space)
dot_coords = transformPointsForward(tform, objs([1,2], match_col)');

% ====================================================================

num_cells = max(labeled_cells(:));
num_dots = size(dot_coords, 1);
dot_counts = zeros(1, num_cells);

% 3. Extract exact sub-pixel coordinates
x_dots = dot_coords(:,1);
y_dots = dot_coords(:,2);

% 4. Check each cell individually using polygons/boundaries
for i = 1:num_cells
    
    % Get the precise boundary coordinates of the mask
    boundaries = bwboundaries(cell_masks);
    
    if ~isempty(boundaries)
        % bwboundaries returns [row, col], so we flip to get [x, y]
        cell_boundary = boundaries{i};
        x_poly = cell_boundary(:, 2);
        y_poly = cell_boundary(:, 1);
        
        % 3. Check if the precise coordinates fall inside this polygon
        in_cell = inpolygon(x_dots, y_dots, x_poly, y_poly);
        
        % 4. Count the dots inside this cell
        dot_counts(i) = sum(in_cell);
    end
end

%%
% Result = table;
% Result.ID = (1:num_cells)';
% Result.narI_counts = dot_counts'; % frame 1
% Result.narJ_counts = dot_counts'; % frame 2
% Result.narH_counts = dot_counts'; % frame 3
Result.narG_counts = dot_counts'; % frame 4

%%
PixelSize = 0.05;      % micron / pixel

% I = imread(ImageFile);
% % Connected components
% Connectivity = 8;

CC = bwconncomp(cell_masks);

% Region properties
Stats = regionprops(CC,...
    'Area',...
    'Perimeter',...
    'Centroid',...
    'BoundingBox',...
    'MajorAxisLength',...
    'MinorAxisLength',...
    'Eccentricity',...
    'EquivDiameter',...
    'Orientation',...
    'Extent',...
    'Solidity');

% Area
Area_pixels = [Stats.Area]';
Area_um2 = Area_pixels * PixelSize^2;

% Result.Area_pixels = Area_pixels;
Result.Area_um2 = Area_um2;

% Perimeter
Perimeter_pixels = [Stats.Perimeter]';
Perimeter_um = Perimeter_pixels * PixelSize;

% Result.Perimeter_pixels = Perimeter_pixels;
Result.Perimeter_um = Perimeter_um;

% Circularity
Circularity = 4*pi*Area_pixels ./ (Perimeter_pixels.^2);

Result.Circularity = Circularity;

% Equivalent diameter
EqDiameter_pixels = [Stats.EquivDiameter]';
EqDiameter_um = EqDiameter_pixels * PixelSize;

% Result.EquivalentDiameter_pixels = EqDiameter_pixels;
Result.EquivalentDiameter_um = EqDiameter_um;

% Major / Minor axis
Major_pixels = [Stats.MajorAxisLength]';
Minor_pixels = [Stats.MinorAxisLength]';

% Result.MajorAxis_pixels = Major_pixels;
% Result.MinorAxis_pixels = Minor_pixels;

Result.MajorAxis_um = Major_pixels * PixelSize;
Result.MinorAxis_um = Minor_pixels * PixelSize;

% Aspect ratio
Result.AspectRatio = Major_pixels ./ Minor_pixels;

% Eccentricity
Result.Eccentricity = [Stats.Eccentricity]';

% Solidity
Result.Solidity = [Stats.Solidity]';

% Extent
Result.Extent = [Stats.Extent]';

% Orientation
Result.Orientation_deg = [Stats.Orientation]';

% Centroid
Centroid = cat(1,Stats.Centroid);

% Result.CentroidX_pixels = Centroid(:,1);
% Result.CentroidY_pixels = Centroid(:,2);

Result.CentroidX_um = Centroid(:,1)*PixelSize;
Result.CentroidY_um = Centroid(:,2)*PixelSize;

% Bounding box
BBox = cat(1,Stats.BoundingBox);

Result.BBoxX = BBox(:,1);
Result.BBoxY = BBox(:,2);
Result.BBoxWidth = BBox(:,3);
Result.BBoxHeight = BBox(:,4);

% Export

OutputFile = 'Cell_mRNA-counts_Geometry.csv';

writetable(Result, OutputFile);

