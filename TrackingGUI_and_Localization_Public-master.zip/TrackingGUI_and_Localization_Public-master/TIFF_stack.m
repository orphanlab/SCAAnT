clc; clear all;

outputStack = 'directory/O-open/crop4/Stack_crop4_2-4.tif';
imageFiles = dir('directory/O-open/crop4/*.tif'); % Path to your individual images

for k = 1:length(imageFiles)
    % Read individual image
    currentFile = fullfile(imageFiles(k).folder, imageFiles(k).name);
    img = imread(currentFile);
    
    % Determine write mode
    if k == 1
        mode = 'overwrite';
    else
        mode = 'append';
    end
    
    % Append to the target TIFF stack
    imwrite(img, outputStack, 'WriteMode', mode);
end
