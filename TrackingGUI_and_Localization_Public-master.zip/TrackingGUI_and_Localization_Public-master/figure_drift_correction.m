clc; clear all;

cd('O-open/crop1');

% Load page 1 as the fixed reference image
fixed = dir('221-*.tif');
fixedImage = imread(fixed.name);

% Load page 2 as the moving image to align
moving = dir('222-*.tif');
movingImage = imread(moving.name);

% Estimate the geometric transformation
tform = imregcorr(movingImage, fixedImage);


%% batch-processing script to register all pages of a multi-page TIFF file to the first page.

% Define file name
fileName = 'directory/O-open/crop1/Stack_crop1.tif';

% Get total page count using TIFF info metadata
info = imfinfo(fileName);
numPages = numel(info);

% Read the first page as the fixed reference image
fixed = imread(fileName, 1);
[rows, cols] = size(fixed);

% Pre-allocate an array for the registered output images
registeredStack = zeros(rows, cols, numPages, 'like', fixed);
registeredStack(:,:,1) = fixed; % Page 1 is already aligned to itself

% Pre-allocate cell array to store the transformations if needed
tforms = cell(numPages, 1);

% Define an execution output view for the transformation wrap
Rfixed = imref2d(size(fixed));

% Loop through all remaining pages
for p = 2:numPages
    % Read current page
    moving = imread(fileName, p);
    
    % Estimate the geometric transformation matrix
    tform = imregcorr(moving, fixed);
    tforms{p} = tform;
    
    % Apply transformation to align the moving image
    registeredStack(:,:,p) = imwarp(moving, tform, 'OutputView', Rfixed);
end

disp('Registration complete!');

